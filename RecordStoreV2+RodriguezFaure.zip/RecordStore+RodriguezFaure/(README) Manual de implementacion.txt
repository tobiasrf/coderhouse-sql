Dentro de la carpeta 'SCRIPTS record_store' se encuentran los archivos necesarios para la implementación de la base de datos.

Los mismos deben ejecutarse dentro de MySQL en el siguiente orden:

01-CREATE.sql
02-INSERT.sql
03-VIEWS.sql
04-FUNCTIONS.sql
05-STORED_PROCEDURES.sql