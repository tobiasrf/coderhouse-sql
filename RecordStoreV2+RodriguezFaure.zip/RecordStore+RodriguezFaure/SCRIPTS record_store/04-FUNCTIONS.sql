DROP FUNCTION IF EXISTS obtener_stock;
DELIMITER //
CREATE FUNCTION obtener_stock(idVinilo INT)
RETURNS INT
DETERMINISTIC
BEGIN
    DECLARE resultado INT;
    SELECT cantidad
    INTO resultado
    FROM stock
    WHERE id_vinilo = idVinilo
    LIMIT 1;

    RETURN IFNULL(resultado, 0);
END //
DELIMITER ;

DROP FUNCTION IF EXISTS total_gastado_por_cliente
DELIMITER //
CREATE FUNCTION total_gastado_por_cliente(clienteId INT)
RETURNS DECIMAL(10,2)
DETERMINISTIC
BEGIN
    RETURN (SELECT IFNULL(SUM(total), 0) FROM compras WHERE id_cliente = clienteId);
END //
DELIMITER ;
