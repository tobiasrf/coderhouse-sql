DROP PROCEDURE IF EXISTS actualizar_stock;
DELIMITER //
CREATE PROCEDURE actualizar_stock (
    IN p_id_vinilo INT,
    IN p_cantidad INT
)
BEGIN
    IF EXISTS (SELECT 1 FROM stock WHERE id_vinilo = p_id_vinilo) THEN
        UPDATE stock
        SET cantidad = cantidad + p_cantidad
        WHERE id_vinilo = p_id_vinilo;
    ELSE
        INSERT INTO stock (id_vinilo, cantidad)
        VALUES (p_id_vinilo, p_cantidad);
    END IF;
END //
DELIMITER ;

DROP PROCEDURE IF EXISTS eliminar_cliente;
DELIMITER //
CREATE PROCEDURE eliminar_cliente (IN p_id_cliente INT)
BEGIN
    DELETE FROM clientes WHERE id_cliente = p_id_cliente;
END //
DELIMITER ;
