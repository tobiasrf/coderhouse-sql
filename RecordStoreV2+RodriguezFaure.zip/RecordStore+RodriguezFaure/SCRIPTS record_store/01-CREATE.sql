DROP SCHEMA IF EXISTS record_store;
CREATE SCHEMA IF NOT EXISTS record_store;
USE record_store;

-- Tabla de géneros
DROP TABLE IF EXISTS generos;
CREATE TABLE IF NOT EXISTS generos (
    id_genero INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(100) NOT NULL
);

-- Tabla de artistas
DROP TABLE IF EXISTS artistas;
CREATE TABLE IF NOT EXISTS artistas (
    id_artista INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(100) NOT NULL,
    id_genero INT NOT NULL,
    FOREIGN KEY (id_genero) REFERENCES generos(id_genero)
);

-- Tabla de vinilos
DROP TABLE IF EXISTS vinilos;
CREATE TABLE IF NOT EXISTS vinilos (
    id_vinilo INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(150) NOT NULL,
    id_artista INT NOT NULL,
    precio DECIMAL(6,2) NOT NULL,
    FOREIGN KEY (id_artista) REFERENCES artistas(id_artista)
);

-- Tabla de stock
DROP TABLE IF EXISTS stock;
CREATE TABLE IF NOT EXISTS stock (
id_stock INT AUTO_INCREMENT PRIMARY KEY,
id_vinilo INT NOT NULL,
cantidad INT,
FOREIGN KEY (id_vinilo) REFERENCES vinilos(id_vinilo)
);

-- Tabla de clientes
DROP TABLE IF EXISTS clientes;
CREATE TABLE IF NOT EXISTS clientes (
    id_cliente INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(255) NOT NULL,
    email VARCHAR(255) NOT NULL UNIQUE
);

-- Tabla de metodos de pago
DROP TABLE IF EXISTS metodos_pago;
CREATE TABLE IF NOT EXISTS metodos_pago (
id_metodo_pago INT AUTO_INCREMENT PRIMARY KEY,
metodo_pago VARCHAR(50) NOT NULL
);

-- Tabla de compras
DROP TABLE IF EXISTS compras;
CREATE TABLE IF NOT EXISTS compras (
    id_compra INT AUTO_INCREMENT PRIMARY KEY,
    id_cliente INT NOT NULL,
    fecha_compra DATE NOT NULL,
    hora_compra TIME NOT NULL,
    id_metodo_pago INT NOT NULL,
    total DECIMAL(10, 2) NOT NULL,
    FOREIGN KEY (id_cliente) REFERENCES record_store.clientes(id_cliente) ON DELETE CASCADE,
    FOREIGN KEY (id_metodo_pago) REFERENCES record_store.metodos_pago(id_metodo_pago) ON DELETE CASCADE
);

-- Tabla de detalles de las compras
DROP TABLE IF EXISTS detalles_compras;
CREATE TABLE IF NOT EXISTS detalles_compras (
    id_detalle INT AUTO_INCREMENT PRIMARY KEY,
    id_compra INT NOT NULL,
    id_vinilo INT NOT NULL,
    precio_unitario DECIMAL(10, 2) NOT NULL,
    cantidad INT NOT NULL,
    subtotal DECIMAL(10, 2) GENERATED ALWAYS AS (precio_unitario * cantidad) STORED,
    FOREIGN KEY (id_compra) REFERENCES record_store.compras(id_compra) ON DELETE CASCADE,
    FOREIGN KEY (id_vinilo) REFERENCES record_store.vinilos(id_vinilo) ON DELETE CASCADE
);

