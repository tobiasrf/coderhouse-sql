CREATE VIEW vista_historial_compras_clientes AS
SELECT
    c.id_cliente,
    c.nombre AS nombre_cliente,
    c.email,
    co.fecha_compra,
    v.nombre AS nombre_vinilo,
    a.nombre AS nombre_artista,
    g.nombre AS genero,
    co.cantidad,
    v.precio,
    (co.cantidad * v.precio) AS total
FROM clientes c
JOIN compras co ON c.id_cliente = co.id_cliente
JOIN vinilos v ON co.id_vinilo = v.id_vinilo
JOIN artistas a ON v.id_artista = a.id_artista
JOIN generos g ON a.id_genero = g.id_genero
ORDER BY c.id_cliente, co.fecha_compra DESC;

CREATE VIEW vista_total_gastado_por_cliente AS
SELECT
    c.id_cliente,
    c.nombre AS nombre_cliente,
    SUM(co.cantidad * v.precio) AS total_gastado,
    COUNT(*) AS cantidad_compras
FROM clientes c
JOIN compras co ON c.id_cliente = co.id_cliente
JOIN vinilos v ON co.id_vinilo = v.id_vinilo
GROUP BY c.id_cliente
ORDER BY total_gastado DESC;

CREATE VIEW vista_vinilos_mas_comprados AS
SELECT
    v.id_vinilo,
    v.nombre AS nombre_vinilo,
    a.nombre AS artista,
    SUM(co.cantidad) AS total_vendido
FROM vinilos v
JOIN artistas a ON v.id_artista = a.id_artista
JOIN compras co ON v.id_vinilo = co.id_vinilo
GROUP BY v.id_vinilo
ORDER BY total_vendido DESC;

CREATE VIEW vista_artistas_por_genero AS
SELECT
    g.nombre AS genero,
    a.nombre AS artista
FROM generos g
JOIN artistas a ON g.id_genero = a.id_genero
ORDER BY genero, artista;

CREATE VIEW vista_clientes_por_genero_comprado AS
SELECT DISTINCT
    c.id_cliente,
    c.nombre AS nombre_cliente,
    g.nombre AS genero
FROM clientes c
JOIN compras co ON c.id_cliente = co.id_cliente
JOIN vinilos v ON co.id_vinilo = v.id_vinilo
JOIN artistas a ON v.id_artista = a.id_artista
JOIN generos g ON a.id_genero = g.id_genero
ORDER BY c.nombre, genero;
