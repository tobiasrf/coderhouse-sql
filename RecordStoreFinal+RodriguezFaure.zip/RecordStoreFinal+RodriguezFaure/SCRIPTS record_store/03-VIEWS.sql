CREATE OR REPLACE VIEW vista_catalogo_vinilos AS
SELECT 
    v.id_vinilo,
    v.nombre AS nombre_vinilo,
    a.nombre AS artista,
    g.nombre AS genero,
    v.precio
FROM vinilos v
JOIN artistas a ON v.id_artista = a.id_artista
JOIN generos g ON a.id_genero = g.id_genero;

CREATE OR REPLACE VIEW vista_compras_por_cliente AS
SELECT 
    c.id_compra,
    cl.nombre AS cliente,
    c.fecha_compra,
    c.hora_compra,
    mp.metodo_pago,
    dc.cantidad,
    v.nombre AS vinilo,
    dc.precio_unitario,
    dc.subtotal,
    c.total
FROM compras c
JOIN clientes cl ON c.id_cliente = cl.id_cliente
JOIN metodos_pago mp ON c.id_metodo_pago = mp.id_metodo_pago
JOIN detalles_compras dc ON c.id_compra = dc.id_compra
JOIN vinilos v ON dc.id_vinilo = v.id_vinilo;

CREATE OR REPLACE VIEW vista_stock_vinilos AS
SELECT 
    v.id_vinilo,
    v.nombre AS nombre_vinilo,
    s.cantidad AS stock_disponible
FROM vinilos v
JOIN stock s ON v.id_vinilo = s.id_vinilo;

CREATE OR REPLACE VIEW vista_total_compras_cliente AS
SELECT 
    cl.id_cliente,
    cl.nombre,
    SUM(c.total) AS total_gastado
FROM clientes cl
JOIN compras c ON cl.id_cliente = c.id_cliente
GROUP BY cl.id_cliente;

CREATE OR REPLACE VIEW vista_artistas_por_genero AS
SELECT 
    g.nombre AS genero,
    COUNT(DISTINCT a.id_artista) AS cantidad_artistas,
    COUNT(v.id_vinilo) AS cantidad_vinilos
FROM generos g
JOIN artistas a ON g.id_genero = a.id_genero
JOIN vinilos v ON a.id_artista = v.id_artista
GROUP BY g.id_genero;

CREATE OR REPLACE VIEW vista_compras_recientes AS
SELECT 
    c.id_compra,
    cl.nombre AS cliente,
    c.fecha_compra,
    c.total
FROM compras c
JOIN clientes cl ON c.id_cliente = cl.id_cliente
WHERE c.fecha_compra >= CURDATE() - INTERVAL 30 DAY;

CREATE OR REPLACE VIEW vista_metodos_pago_usados AS
SELECT 
    mp.metodo_pago,
    COUNT(*) AS cantidad_usos
FROM compras c
JOIN metodos_pago mp ON c.id_metodo_pago = mp.id_metodo_pago
GROUP BY mp.id_metodo_pago
ORDER BY cantidad_usos DESC;
