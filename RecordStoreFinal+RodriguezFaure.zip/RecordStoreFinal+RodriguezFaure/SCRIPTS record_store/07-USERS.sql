-- Usuario solo lectura
CREATE USER 'asistente_lectura'@'localhost' IDENTIFIED BY 'lectura123';
GRANT SELECT ON record_store.* TO 'asistente_lectura'@'localhost';

-- Usuario con permisos de lectura e inserción
CREATE USER 'asistente_insercion'@'localhost' IDENTIFIED BY 'insercion123';
GRANT SELECT, INSERT ON record_store.* TO 'asistente_insercion'@'localhost';

-- Usuario con permisos de administración completa
CREATE USER 'administrador_full'@'localhost' IDENTIFIED BY 'admin123';
GRANT ALL PRIVILEGES ON record_store.* TO 'administrador_full'@'localhost';
