DELIMITER //
CREATE TRIGGER trg_descuento_stock
AFTER INSERT ON detalles_compras
FOR EACH ROW
BEGIN
    UPDATE stock
    SET cantidad = cantidad - NEW.cantidad
    WHERE id_vinilo = NEW.id_vinilo;
END;
//
DELIMITER ;

-- Auditoria clientes
CREATE TABLE IF NOT EXISTS auditoria_clientes (
    id_auditoria INT AUTO_INCREMENT PRIMARY KEY,
    id_cliente INT,
    nombre_cliente VARCHAR(100),
    accion VARCHAR(10),
    fecha TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

DELIMITER //
CREATE TRIGGER trg_auditar_clientes_update
AFTER UPDATE ON clientes
FOR EACH ROW
BEGIN
    INSERT INTO auditoria_clientes (id_cliente, nombre_cliente, accion)
    VALUES (OLD.id_cliente, OLD.nombre, 'UPDATE');
END;
//
DELIMITER ;

DELIMITER //
CREATE TRIGGER trg_auditar_clientes_delete
AFTER DELETE ON clientes
FOR EACH ROW
BEGIN
    INSERT INTO auditoria_clientes (id_cliente, nombre_cliente, accion)
    VALUES (OLD.id_cliente, OLD.nombre, 'DELETE');
END;
//
DELIMITER ;
